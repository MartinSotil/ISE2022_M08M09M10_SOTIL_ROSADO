#ifndef LED_RGB_H
#define LED_RGB_H
#include "LPC17xx.h"
#include "GPIO_LPC17xx.h"

void Init_RGB(void);
void led_verde(void);
void led_rojo(void);
void apagar_led(void);
void led_azul(void);

#endif