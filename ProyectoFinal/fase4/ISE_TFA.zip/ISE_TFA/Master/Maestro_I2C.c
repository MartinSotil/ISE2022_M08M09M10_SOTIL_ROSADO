#include "Maestro_I2C.h"
/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/

uint32_t addr = Esclavo_I2C_ADDR;
int32_t status = 0, contador = 0;
uint8_t buf[3];
uint16_t temp;
float temperatura;
int num_bytes_enviar;
uint8_t C1;
extern uint8_t cmd[3];

//Para guardar el timeStamp
int hora_ver;
int min_ver;
int sec_ver;
int dia_ver;
int mes_ver;
int ano_ver;


/* I2C driver instance */
extern ARM_DRIVER_I2C            Driver_I2C2;
static  ARM_DRIVER_I2C *I2Cdrv = &Driver_I2C2;


static volatile uint32_t I2C_Event;

void funcTimer5s (void const *argument);
osTimerDef(Timer5s,funcTimer5s);
uint32_t exec5s;
osTimerId boolTimer5s;

void Thread (void const *argument);                             // thread function
extern osThreadId tid_Maestro_I2C;                                          // thread id
osThreadDef (Maestro_I2C, osPriorityNormal, 1, 0);                   // thread object

void funcTimer5s (void const *argument) {
	salto_overload=false;
	apagar_led();
	osTimerStop(boolTimer5s);
}

int Init_timers(void){
	boolTimer5s=osTimerCreate(osTimer(Timer5s),osTimerOnce,&exec5s);
	if(! boolTimer5s) return(-1);
	return (0);
}
/* I2C Signal Event function callback */
void I2C_SignalEvent (uint32_t event) {
 
  /* Save received events */
  I2C_Event |= event;
 
  /* Optionally, user can define specific actions for an event */
 
  if (event & ARM_I2C_EVENT_TRANSFER_INCOMPLETE) {
    /* Less data was transferred than requested */
  }
 
  if (event & ARM_I2C_EVENT_TRANSFER_DONE) {
    /* Transfer or receive is finished */
		
		osSignalSet (tid_Maestro_I2C, SIG_Esclavo_I2C);

  }
 
  if (event & ARM_I2C_EVENT_ADDRESS_NACK) {
    /* Slave address was not acknowledged */
  }
 
  if (event & ARM_I2C_EVENT_ARBITRATION_LOST) {
    /* Master lost bus arbitration */
  }
 
  if (event & ARM_I2C_EVENT_BUS_ERROR) {
    /* Invalid start/stop position detected */
  }
 
  if (event & ARM_I2C_EVENT_BUS_CLEAR) {
    /* Bus clear operation completed */
  }
 
  if (event & ARM_I2C_EVENT_GENERAL_CALL) {
    /* Slave was addressed with a general call address */
  }
 
  if (event & ARM_I2C_EVENT_SLAVE_RECEIVE) {
    /* Slave addressed as receiver but SlaveReceive operation is not started */
  }
 
  if (event & ARM_I2C_EVENT_SLAVE_TRANSMIT) {
    /* Slave addressed as transmitter but SlaveTransmit operation is not started */
  }
}

void Init_i2c(void){
	
	int32_t status;
	
  status = I2Cdrv->Initialize (I2C_SignalEvent);
  status = I2Cdrv->PowerControl (ARM_POWER_FULL);
  status = I2Cdrv->Control      (ARM_I2C_BUS_SPEED, ARM_I2C_BUS_SPEED_STANDARD);
  status = I2Cdrv->Control      (ARM_I2C_BUS_CLEAR, 0);
	
}

int Init_Maestro_I2C (void) {
  GPIO_SetDir(0,23,GPIO_DIR_INPUT);
	LPC_GPIOINT->IO0IntEnR |= ( 1 << 23);
	LPC_GPIOINT->IO0IntClr |= ( 1 << 23);
	NVIC_EnableIRQ(EINT3_IRQn);
	osTimerStart(boolTimer5s,1500);
  tid_Maestro_I2C = osThreadCreate (osThread(Maestro_I2C), NULL);
  if (!tid_Maestro_I2C) return(-1);
  return(0);
}

void Maestro_I2C (void const *argument) {

	osEvent evento_maestro;
	while(1){
		
		evento_maestro = osSignalWait(0,osWaitForever);
		
		switch(evento_maestro.value.signals){
			
			case 0x0002:
				//Enviamos, incrementado una unidad cada vez
				status = I2Cdrv->MasterTransmit(addr, cmd, 3, true);
				osSignalWait (SIG_Esclavo_I2C, osWaitForever); 
				
				//Esperamos a recibir:
				status = I2Cdrv->MasterReceive(addr, buf, 3, true);
			  analizar_tramas_recepcion(buf[0]);
				osSignalWait (SIG_Esclavo_I2C, osWaitForever); 
			  osSignalClear(tid_Maestro_I2C,0x0002);
			break;
			case 0x0004:
			osTimerStop(boolTimer5s);
	    osTimerStart(boolTimer5s,1500);
		  led_rojo();
		  salto_overload=true;
			modificarXposicion(22,0x00040000,hora_ver,4);
			modificarXposicion(22,0x00040000,min_ver,5);
			modificarXposicion(22,0x00040000,sec_ver,6);
			osDelay(50);
			osSignalClear(tid_Maestro_I2C,0x0004);
			break;
    }
  }
}

void EINT3_IRQHandler (void){  //Segnal de interrupcion de comunicacion con el esclavo
	
	if(LPC_GPIOINT->IO0IntStatR&(1 << 23)){
      osSignalSet(tid_Maestro_I2C,0x0004);
		  LPC_GPIOINT->IO0IntClr |= ( 1 << 23); //Limpiamos el flag de la interrupcion
		}
}

void analizar_tramas_recepcion(uint8_t trama){
  if(trama!=0x04){ //Es simplemente que no quiere devolver nada
	switch(trama){
    case 0x01: //Devuelve la ganancia
		  if(buf[1]==REG_GANANCIA_1){
				ganancia=1;
			}else if(buf[1]==REG_GANANCIA_5){
				ganancia=5;
			}else if(buf[1]==REG_GANANCIA_10){
				ganancia=10;
			}else if(buf[1]==REG_GANANCIA_50){
				ganancia=50;
			}else if(buf[1]==REG_GANANCIA_100){
				ganancia=100;
			}
		break;
		case 0x02: //Devuelve el overload
			overload=((double)((buf[1]*10)+buf[2]))/10;
		break;
	  case 0x03: //Devuelve estado overload
			salto_overload=(bool)buf[1];
		break;
	}
 }		
}

