#define LCD_H
#ifdef LCD_H

#include "LPC17xx.h"
#include "LCD.h"
#include "cmsis_os.h"
#include "HTTP_Server_CGI.h"
#include "Led_RGB.h"
#include "LCD.h"
#include "SNTP.h"

void Init_pulsador(void);
	
#endif
