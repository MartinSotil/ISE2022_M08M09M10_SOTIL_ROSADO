#include "gestor_pulsador.h"
#include "Maestro_I2C.h"

#define DOWN                  17
#define LEFT                  15
#define CENTER                16
#define UP                    23
#define RIGHT                 24

uint8_t cmd[3]; //Para enviarle los datos al esclavo
osThreadId tid_Maestro_I2C;
double overload_en_double;
int ganancia;
double parteDecimal;
double parteEntera;
int mayorPeso;
int menorPeso;
uint8_t composicion;
char NuevoOverload[10]="4.8";


void rebotes (void const *argument);

osThreadId tid_rebotes; 

osThreadDef (rebotes, osPriorityNormal, 1, 0);    


void Init_pulsador(void) {
	
	 PIN_Configure(0,LEFT,PIN_FUNC_0,PIN_PINMODE_PULLDOWN,PIN_PINMODE_NORMAL);          
	 PIN_Configure(0,CENTER,PIN_FUNC_0,PIN_PINMODE_PULLDOWN,PIN_PINMODE_NORMAL);
	 PIN_Configure(0,DOWN,PIN_FUNC_0,PIN_PINMODE_PULLDOWN,PIN_PINMODE_NORMAL);
	 PIN_Configure(0,UP,PIN_FUNC_0,PIN_PINMODE_PULLDOWN,PIN_PINMODE_NORMAL);
	 PIN_Configure(0,RIGHT,PIN_FUNC_0,PIN_PINMODE_PULLDOWN,PIN_PINMODE_NORMAL);

	LPC_GPIOINT->IO0IntEnR |= ( 1 << LEFT)|( 1 << UP) |( 1 << CENTER)|( 1 << DOWN)|( 1 << RIGHT);
	tid_rebotes = osThreadCreate (osThread(rebotes), NULL);
  
	
	LPC_GPIOINT->IO0IntClr |= ( 1 << LEFT);
	LPC_GPIOINT->IO0IntClr |= ( 1 << DOWN);
  LPC_GPIOINT->IO0IntClr |= ( 1 << UP);
	LPC_GPIOINT->IO0IntClr |= ( 1 << CENTER);
	LPC_GPIOINT->IO0IntClr |= ( 1 << RIGHT);
	NVIC_EnableIRQ(EINT3_IRQn);


}

void rebotes (void const *argument) {

	osEvent pulso_rise;

	while(1){
	pulso_rise = osSignalWait(0,osWaitForever); //El 0 hace que se pare
  switch(pulso_rise.value.signals){
     case 0x0001:
			  osDelay(100); //CASO RISE
				LPC_GPIOINT->IO0IntEnF |= ( 1 << LEFT)|( 1 << UP) |( 1 << CENTER)|( 1 << DOWN)|( 1 << RIGHT);	//Activamos las de bajada
				osSignalClear(tid_rebotes,0x0001);
		break;
		 
		  case 0x0002: //CASO FALL
				osDelay(100); //Eliminamos rebotes
		    LPC_GPIOINT->IO0IntEnR |= ( 1 << LEFT)|( 1 << UP) |( 1 << CENTER)|( 1 << DOWN)|( 1 << RIGHT); //Activamos las de subida
				osSignalClear(tid_rebotes,0x0002);
		break;
  }
 }
}

void EINT3_IRQHandler (void){    
	 
	  //*********************************************
	  //FLANCO SUBIDA
	  //*********************************************
		if(LPC_GPIOINT->IO0IntStatR&(1 << UP)){    
	  	cmd[0]=REG_GANANCIA_1;
			cmd[1]=0x00;
			cmd[2]=0x00;
      osSignalSet(tid_Maestro_I2C,0x0002);
			osSignalSet(tid_rebotes,0x0001);	                       
			LPC_GPIOINT->IO0IntEnR &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);
		  LPC_GPIOINT->IO0IntClr =( 1 << UP);
	  }
		if(LPC_GPIOINT->IO0IntStatR&(1 << DOWN)){   
	  	cmd[0]=REG_GANANCIA_5;
			cmd[1]=0x00;
			cmd[2]=0x00;
      osSignalSet(tid_Maestro_I2C,0x0002);
			osSignalSet(tid_rebotes,0x0001);	                      
			LPC_GPIOINT->IO0IntEnR &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);
		  LPC_GPIOINT->IO0IntClr =( 1 << DOWN);
		
	  }
		if(LPC_GPIOINT->IO0IntStatR&(1 << LEFT)){   
	  		cmd[0]=REG_PROGRAMAR_UMBRAL;
				overload_en_double=atof(NuevoOverload); //Pasar de cadena de caracteres a entero
				parteDecimal=modf(overload_en_double,&parteEntera);
				mayorPeso=(int)(parteEntera);
				menorPeso=(int)((parteDecimal*10));
				cmd[1]=(uint8_t)mayorPeso;
			  cmd[2]=(uint8_t)menorPeso;
			  osSignalSet(tid_Maestro_I2C,0x0002);
			
			osSignalSet(tid_rebotes,0x0001);	                       
			LPC_GPIOINT->IO0IntEnR &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);
	    LPC_GPIOINT->IO0IntClr =( 1 << LEFT);
		
	  }
		if(LPC_GPIOINT->IO0IntStatR&(1 << RIGHT)){  
	  	cmd[0]=REG_GANANCIA_10;
			cmd[1]=0x00;
			cmd[2]=0x00;
      osSignalSet(tid_Maestro_I2C,0x0002);
			osSignalSet(tid_rebotes,0x0001);	                       
			LPC_GPIOINT->IO0IntEnR &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);
	    LPC_GPIOINT->IO0IntClr =( 1 << RIGHT);
		
	  }
		if(LPC_GPIOINT->IO0IntStatR&(1 << CENTER)){   
			cmd[0]=REG_GANANCIA_100;
			cmd[1]=0x00;
			cmd[2]=0x00;
			osSignalSet(tid_Maestro_I2C,0x0002);
			osSignalSet(tid_rebotes,0x0001);
			LPC_GPIOINT->IO0IntEnR &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);
	    LPC_GPIOINT->IO0IntClr =( 1 << CENTER);
      
	  }
		
		
    //*********************************************************************
		//FLANCO BAJADA
		//*********************************************************************
		if( LPC_GPIOINT->IO0IntStatF&(1 << UP)){   
			osSignalSet(tid_rebotes,0x0002);	
      LPC_GPIOINT->IO0IntEnF &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);
      LPC_GPIOINT->IO0IntClr =( 1 << UP);				
	  } 
		if( LPC_GPIOINT->IO0IntStatF&(1 << DOWN)){   	   
			osSignalSet(tid_rebotes,0x0002);
      LPC_GPIOINT->IO0IntEnF &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);			
      LPC_GPIOINT->IO0IntClr =( 1 << DOWN);			
	  }
		if( LPC_GPIOINT->IO0IntStatF&(1 << LEFT)){    	   
			osSignalSet(tid_rebotes,0x0002);
      LPC_GPIOINT->IO0IntEnF &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);			
      LPC_GPIOINT->IO0IntClr =( 1 << LEFT);			
	  }
		if( LPC_GPIOINT->IO0IntStatF&(1 << RIGHT)){       
			osSignalSet(tid_rebotes,0x0002);	
			LPC_GPIOINT->IO0IntEnF &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);
      LPC_GPIOINT->IO0IntClr =( 1 << RIGHT);			
	  }
		if( LPC_GPIOINT->IO0IntStatF&(1 << CENTER)){       
			osSignalSet(tid_rebotes,0x0002);
			LPC_GPIOINT->IO0IntEnF &= ~( 1 << LEFT)|~( 1 << UP) |~( 1 << CENTER)|~( 1 << DOWN)|~( 1 << RIGHT);
      LPC_GPIOINT->IO0IntClr =( 1 << CENTER);			
	  }
		
}
	
