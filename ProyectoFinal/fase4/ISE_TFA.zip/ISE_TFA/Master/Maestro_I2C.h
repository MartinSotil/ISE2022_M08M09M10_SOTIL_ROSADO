#ifndef MAESTRO_I2C_H
#define MAESTRO_I2C_H

#include "cmsis_os.h"                                           // CMSIS RTOS header file
#include "Driver_I2C.h"
#include "Led_RGB.h"
#include "math.h"
#include "HTTP_Server_CGI.h"
#include "gestion_FLASH.h"

#define Esclavo_I2C_ADDR       	      0x28      
 
 
#define REG_GANANCIA_1   					    				0x01
#define REG_GANANCIA_5   					    				0x02
#define REG_GANANCIA_10    					  				0x03
#define REG_GANANCIA_50    					  				0x04
#define REG_GANANCIA_100    									0x05

#define REG_PROGRAMAR_UMBRAL	    						0x06
#define REG_HABILITAR_UMBRAL	    						0x07
#define REG_DESHABILITAR_UMBRAL   						0x08
#define REG_PETICION_GANANCIA	    						0x09
#define REG_PETICION_OVERLOAD	        				0x0A
#define REG_PETICION_ESTADO_OVERLOAD		   		0x0B

#define SIG_Esclavo_I2C							0x0001      
  
#define Esclavo_I2C_ADDR       	      0x28      


extern bool salto_overload;

void Init_i2c(void);
void Maestro_I2C (void const *argument);
int Init_Maestro_I2C(void);
int Init_timers(void);
void analizar_tramas_recepcion(uint8_t trama);

#endif
