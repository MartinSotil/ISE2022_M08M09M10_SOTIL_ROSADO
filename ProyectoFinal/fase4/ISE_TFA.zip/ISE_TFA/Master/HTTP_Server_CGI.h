#ifndef HTTP_SERVER_CGI_H
#define HTTP_SERVER_CGI_H

#include <stdio.h>
#include <string.h>
#include "rl_net.h"
#include "rl_net_lib.h"
#include "pinoutConfigure.h"
#include "stdio.h"
#include <stdlib.h>
#include "Maestro_I2C.h"

extern bool bool_leds_barrido;

extern double overload;
extern int ganancia;
//extern bool activarOverload;

extern char lcd_text[2][20+1];

extern bool LEDrun;
extern bool SNTP_Choose_IP;

int devolverGananciaAI(void);


#endif
