/*------------------------------------------------------------------------------
 * MDK Middleware - Component ::Network
 * Copyright (c) 2004-2014 ARM Germany GmbH. All rights reserved.
 *------------------------------------------------------------------------------
 * Name:    HTTP_Server.c
 * Purpose: HTTP Server example
 *----------------------------------------------------------------------------*/

#include <stdio.h>
#include "HTTP_Server_CGI.h"
#include "cmsis_os.h"                   /* CMSIS RTOS definitions             */
#include "rl_net.h"                     /* Network definitions                */
#include "pinoutConfigure.h"
#include "LCD.h"
#include "adc.h"
#include "SNTP.h"
//#include "gestor_pulsador.h"
#include "HTTP_Server_CGI.h"
#include "gestion_FLASH.h" 
#include "Led_RGB.h"
#include "Maestro_I2C.h"

osThreadId tid_Maestro_I2C;
uint8_t cmd[3];
extern int Init_timers(void);
uint8_t lectura_array_flash[NUM_MAX_POS];

//*****************************OBTENER IP***************
extern ARM_DRIVER_ETH_MAC Driver_ETH_MAC0;
ARM_DRIVER_ETH_MAC *ETH_MAC = &Driver_ETH_MAC0;
 
extern  LOCALM localm[];
#define LocM   localm[NETIF_ETH]

ARM_ETH_MAC_ADDR ETH_MAC_struct;

//OBTENER IP y MAC:
uint8_t bf_MAC[6];
uint8_t ip_device[4];
//******************************************************


bool LEDrun;
uint8_t P2;
//*************************VARIABLES FLASH***********************
uint8_t array[NUM_MAX_POS];
uint8_t arrayRetorno[NUM_MAX_POS];
//***************************************************************

bool escribirLCD1=false;
bool escribirLCD2=false;
bool bool_ADC=false;

uint16_t medida=0;

/// Read analog inputs
uint16_t AD_in (uint32_t ch) {
  int32_t val = 0;

  if (ch == 0) {

    val = conversion_ADC_P0T2();
		if( val>arrayRetorno[12] ){
			led_azul();
		}else{
			apagar_led();
		}
  }
  return (val);
}

/// Read digital inputs
uint8_t get_button (void) {
 // return (Buttons_GetState ());
	return 0;
}

/// IP address change notification
void dhcp_client_notify (uint32_t if_num,
                         dhcpClientOption opt, const uint8_t *val, uint32_t len) {
  if (opt == dhcpClientIPaddress) {
    // IP address has changed
   
  }
}

void request_IP_device(uint8_t *bf_IP){
	
	int i;
	
	for(i = 0; i<4; i++){
		bf_IP[i] = LocM.IpAddr[i];
	}
	
}


void request_MAC_device(uint8_t *bf_MAC){
	
	int i;
	ETH_MAC->GetMacAddress(&ETH_MAC_struct);
	
	for(i = 0; i<6; i++){
		bf_MAC[i]  = ETH_MAC_struct.b[i];
	}
}


/*----------------------------------------------------------------------------
  Main Thread 'main': Run Network
 *---------------------------------------------------------------------------*/
int main (void) {
	
	Init_RGB();
	
 	osKernelInitialize ();
	Init_timers();
  net_initialize     ();
	pinConfiguration();
	init_RTC();
	Init_Maestro_I2C();
	Init_i2c();
	//get_time_ntp();
	init(); //Inicializar el display LCD
	habilitar_deshabilitar_RTC( HABILITADO ); //Habilitar el RTC
	interrupciones_RTC_deshabilitar(); //Deshabilitamos las interrupciones
	interrupciones_RTC( SEGUNDOS );
	osKernelStart ();
  
	
  while(1) {
    net_main ();
    osThreadYield ();
  }
}
