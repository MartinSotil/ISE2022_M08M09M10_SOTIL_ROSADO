#include "DAC.h"

int valor;

void init_dac( void ){
	LPC_PINCON->PINSEL1 |= (1<<21); //DAC en el pin 0.26	
}

void set_value( double voltaje ){
	valor=(int)( voltaje*1023/10 ); //valor=voltaje*1023/10
	if( valor > 1023 ) valor = 1023;
	LPC_DAC->DACR = (valor<<6); //Del bit 6:15 va el valor
  osDelay(10); //Para que le de tiempo a hacer la conversion
}

