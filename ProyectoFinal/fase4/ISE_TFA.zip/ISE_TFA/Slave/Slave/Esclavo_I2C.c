#include "Esclavo_I2C.h"

/*----------------------------------------------------------------------------
 *      Thread 1 'Thread_Name': Sample thread
 *---------------------------------------------------------------------------*/
 



uint32_t addr = Esclavo_I2C_ADDR;
int32_t status = 0, contador = 0;
uint8_t cmd[3], buffer_esclavo[3];
uint8_t Overload_actual;
uint8_t ganancia_actual;
uint8_t EstadoOverload_Actual;
double recomposicion_decimal;
bool primeraVez=true;
uint8_t buffer_esclavo_anterior[3];
uint32_t leer1,leer2;
uint8_t bitMayorPeso;
uint8_t bitMenorPeso;

/* I2C driver instance */
extern ARM_DRIVER_I2C            Driver_I2C2;
static ARM_DRIVER_I2C *I2Cdrv = &Driver_I2C2;


static volatile uint32_t I2C_Event;


void Esclavo_I2C (void const *argument);                             // thread function
osThreadId tid_Esclavo_I2C;                                          // thread id
osThreadDef (Esclavo_I2C, osPriorityNormal, 1, 0);                   // thread object
 
void Interrupcion_overload (void const *argument);                   // thread function
osThreadId tid_overload;                                             // thread id
osThreadDef (Interrupcion_overload, osPriorityNormal, 1, 0);         // thread object

/* I2C Signal Event function callback */
void I2C_SignalEvent (uint32_t event) {
 
  /* Save received events */
  I2C_Event |= event;
 
  /* Optionally, user can define specific actions for an event */
 
  if (event & ARM_I2C_EVENT_TRANSFER_INCOMPLETE) {
    /* Less data was transferred than requested */
  }
 
  if (event & ARM_I2C_EVENT_TRANSFER_DONE) {
    /* Transfer or receive is finished */
		
		osSignalSet (tid_Esclavo_I2C, SIG_Esclavo_I2C);

  }
 
  if (event & ARM_I2C_EVENT_ADDRESS_NACK) {
    /* Slave address was not acknowledged */
  }
 
  if (event & ARM_I2C_EVENT_ARBITRATION_LOST) {
    /* Master lost bus arbitration */
  }
 
  if (event & ARM_I2C_EVENT_BUS_ERROR) {
    /* Invalid start/stop position detected */
  }
 
  if (event & ARM_I2C_EVENT_BUS_CLEAR) {
    /* Bus clear operation completed */
  }
 
  if (event & ARM_I2C_EVENT_GENERAL_CALL) {
    /* Slave was addressed with a general call address */
  }
 
  if (event & ARM_I2C_EVENT_SLAVE_RECEIVE) {
     
    /* Slave addressed as receiver but SlaveReceive operation is not started */
  }
 
  if (event & ARM_I2C_EVENT_SLAVE_TRANSMIT) {
    /* Slave addressed as transmitter but SlaveTransmit operation is not started */
  }
}

void Init_i2c(void){
	
	int32_t status;
	
  status = I2Cdrv->Initialize (I2C_SignalEvent);
  status = I2Cdrv->PowerControl (ARM_POWER_FULL);
  I2Cdrv->Control(ARM_I2C_OWN_ADDRESS, Esclavo_I2C_ADDR );
	
}

int Init_Esclavo_I2C(void) {
  GPIO_SetDir(0,23,GPIO_DIR_OUTPUT);
	GPIO_SetDir(0,1,GPIO_DIR_INPUT);
	GPIO_SetDir(0,0,GPIO_DIR_INPUT);
	//Pines para el multiplexor:
	GPIO_SetDir(1,30,GPIO_DIR_OUTPUT); //A2 (19)
	GPIO_SetDir(0,26,GPIO_DIR_OUTPUT); //A1 (18)
	GPIO_SetDir(0,25,GPIO_DIR_OUTPUT); //A0 (17)
  tid_Esclavo_I2C = osThreadCreate (osThread(Esclavo_I2C), NULL);
	tid_overload=osThreadCreate (osThread(Interrupcion_overload), NULL);
  GPIO_PinWrite(1,30,0); //A2 (19)
	GPIO_PinWrite(0,26,0); //A1 (18)
	GPIO_PinWrite(0,25,0); //A0 (17)
  if (!tid_Esclavo_I2C) return(-1);
	if (!tid_overload) return(-1);
  
  return(0);
}

void Interrupcion_overload(void const *argument){
	while(1){
		leer1=GPIO_PinRead(0,1);
		leer2=GPIO_PinRead(0,0);
		if( (leer1 == 0x00000001 || leer2 == 0x00000001) && EstadoOverload_Actual ){
			GPIO_PinWrite(0,23,0);
			osDelay(10);
			GPIO_PinWrite(0,23,1);
			osDelay(10);
			GPIO_PinWrite(0,23,0);
		}
		osDelay(1200);
	}
}

void Esclavo_I2C  (void const *argument) {
  while (1) {
				I2Cdrv->SlaveReceive(buffer_esclavo,3);
				osSignalWait (SIG_Esclavo_I2C	, osWaitForever);
				if( ( buffer_esclavo_anterior[0] != buffer_esclavo[0]) || (buffer_esclavo_anterior[1]!=buffer_esclavo[1]) || 
				(buffer_esclavo_anterior[2]!=buffer_esclavo[2]) || primeraVez ){
					analizador_tramas(buffer_esclavo[0]);
					buffer_esclavo_anterior[0]=buffer_esclavo[0];
					buffer_esclavo_anterior[1]=buffer_esclavo[1];
          buffer_esclavo_anterior[2]=buffer_esclavo[2]; 
				}
		    primeraVez=false;
				status = I2Cdrv->SlaveTransmit(cmd,3);
				osSignalWait (SIG_Esclavo_I2C	, osWaitForever);  
  }
}	

void analizador_tramas(uint8_t trama){
	    switch(trama){
			case REG_GANANCIA_1:
				cmd[0]=0x04;
				ganancia_actual=REG_GANANCIA_1;
			  GPIO_PinWrite(1,30,0); //A2 (19)
	      GPIO_PinWrite(0,26,0); //A1 (18)
	      GPIO_PinWrite(0,25,1); //A0 (17)
			break;
			
		  case REG_GANANCIA_5:
				cmd[0]=0x04;
			  ganancia_actual=REG_GANANCIA_5;
			  GPIO_PinWrite(1,30,0); //A2 (19)
	      GPIO_PinWrite(0,26,1); //A1 (18)
	      GPIO_PinWrite(0,25,0); //A0 (17)
			break;
						
			case REG_GANANCIA_10:
				cmd[0]=0x04;
				ganancia_actual=REG_GANANCIA_10;
			  GPIO_PinWrite(1,30,0); //A2 (19)
	      GPIO_PinWrite(0,26,1); //A1 (18)
	      GPIO_PinWrite(0,25,1); //A0 (17)
			break;
									
			case REG_GANANCIA_50:
				cmd[0]=0x04;
				ganancia_actual=REG_GANANCIA_50;
			  GPIO_PinWrite(1,30,1); //A2 (19)
	      GPIO_PinWrite(0,26,0); //A1 (18)
	      GPIO_PinWrite(0,25,0); //A0 (17)
			break;
												
			case REG_GANANCIA_100:
				cmd[0]=0x04;
				ganancia_actual=REG_GANANCIA_100;
			  GPIO_PinWrite(1,30,1); //A2 (19)
	      GPIO_PinWrite(0,26,0); //A1 (18)
	      GPIO_PinWrite(0,25,1); //A0 (17)
			break;
															
		  case REG_HABILITAR_UMBRAL:
				cmd[0]=0x04;
				EstadoOverload_Actual=true;
			break;
			
			case REG_DESHABILITAR_UMBRAL:
				cmd[0]=0x04;
				EstadoOverload_Actual=false;
			break;
															
		  case REG_PROGRAMAR_UMBRAL:
			//Va lo del DAC
			cmd[0]=0x04;
			bitMayorPeso=buffer_esclavo[1];
			bitMenorPeso=buffer_esclavo[2];
			recomposicion_decimal=((double)((buffer_esclavo[1]*10)+buffer_esclavo[2]))/10;
			set_value(recomposicion_decimal); //Sacamos el valor por el dac
			break;
																		
			case REG_PETICION_GANANCIA:
			  cmd[0]=0x01;
			  cmd[1]=ganancia_actual;
			  cmd[2]=0x00;
			break;
		  
			case REG_PETICION_OVERLOAD:
			  cmd[0]=0x02;
			  cmd[1]=bitMayorPeso;
			  cmd[2]=bitMenorPeso;
			break;
																		
			case REG_PETICION_ESTADO_OVERLOAD:
				if(EstadoOverload_Actual){
					cmd[1]=0x01;
				}else{
					cmd[1]=0x00;
				}
			  cmd[0]=0x03;
			  cmd[2]=0x00;
			break;
		}
}