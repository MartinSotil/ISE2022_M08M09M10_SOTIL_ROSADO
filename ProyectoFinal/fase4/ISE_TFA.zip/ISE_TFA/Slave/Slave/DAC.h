#ifndef DAC_H
#define DAC_H

#include "LPC17xx.h"
#include "cmsis_os.h"

extern int valor;

void init_dac( void );
void set_value( double voltaje );

#endif